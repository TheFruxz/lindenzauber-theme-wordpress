<?php
/**
 * Title: Seite: Impressum
 * Slug: lindenzauber/seite-impressum
 * Categories: lindenzauber
 * Description: Pflichtangaben mit dem Mütter-Kinder-Zentrum Bassum e. V. als Träger.
 * Block Types: core/post-content
 * Post Types: page
 * Inserter: yes
 *
 * Diese Datei wird von tools/make-patterns.php erzeugt.
 * Quelle: inhalte/07-impressum.html
 *
 * @package Lindenzauber
 */

?>
<!-- wp:heading -->
<h2 class="wp-block-heading">Angaben gemäß § 5 DDG</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Mütter-Kinder-Zentrum Bassum e. V.</strong><br>Mittelstraße 2<br>27211 Bassum</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Vertreten durch den Vorstand: Brigitta Wortmann, Henrike Gerling-Jakobs, Alyona Davtyan, Charlotte Nielsen, Iris Nielsen</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Registergericht: Amtsgericht Walsrode<br>Registernummer: VR 110170</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Kontakt</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>E-Mail: <a href="mailto:info@lindenzauber.de">info@lindenzauber.de</a><br>Telefon: <a href="tel:+491737699963">0173 769 99 63</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Vereinsgeschäftsstelle: <a href="tel:+4942414842">04241 4842</a>, <a href="mailto:info@muekize-bassum.de">info@muekize-bassum.de</a><br><a href="https://www.muekize-bassum.de/" rel="noopener">www.muekize-bassum.de</a></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Brigitta Wortmann<br>Eschenhausen 3<br>27211 Bassum</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Konzeption und Organisation</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Brigitta Wortmann, Märchenerzählerin und Harfenspielerin, im Auftrag des Mütter-Kinder-Zentrums Bassum e. V.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Haftung für Inhalte</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Als Diensteanbieter sind wir für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Wir sind jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen. Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen bleiben hiervon unberührt. Eine diesbezügliche Haftung ist erst ab dem Zeitpunkt der Kenntnis einer konkreten Rechtsverletzung möglich. Bei Bekanntwerden entsprechender Rechtsverletzungen entfernen wir diese Inhalte umgehend.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Haftung für Links</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber verantwortlich. Die verlinkten Seiten wurden zum Zeitpunkt der Verlinkung auf mögliche Rechtsverstöße überprüft; rechtswidrige Inhalte waren nicht erkennbar. Eine permanente inhaltliche Kontrolle der verlinkten Seiten ist ohne konkrete Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen entfernen wir derartige Links umgehend.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Urheberrecht</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechts bedürfen der schriftlichen Zustimmung des jeweiligen Autors beziehungsweise Erstellers. Downloads und Kopien dieser Seite sind nur für den privaten, nicht kommerziellen Gebrauch gestattet. Soweit die Inhalte auf dieser Seite nicht vom Betreiber erstellt wurden, werden die Urheberrechte Dritter beachtet. Sollten Sie dennoch auf eine Urheberrechtsverletzung aufmerksam werden, bitten wir um einen entsprechenden Hinweis. Bei Bekanntwerden von Rechtsverletzungen entfernen wir solche Inhalte umgehend.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Bildnachweise</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Plakat und Gestaltung des Lindenzaubers: Brigitta Wortmann<br>Logos der Förderer: Avacon, Stadt Bassum, Landschaftsverband Weser-Hunte e. V., Volksbank Bassum-Syke – Verwendung mit freundlicher Genehmigung der jeweiligen Rechteinhaber.<br>Kartenausschnitt auf der Programmseite: © OpenStreetMap-Mitwirkende, <a href="https://www.openstreetmap.org/copyright" rel="noopener">Lizenz ODbL</a>.<br>Porträtfotos: privat, sofern nicht anders angegeben.</p>
<!-- /wp:paragraph -->
