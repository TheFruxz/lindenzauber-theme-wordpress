<?php
/**
 * Title: Seite: Kontakt
 * Slug: lindenzauber/seite-kontakt
 * Categories: lindenzauber
 * Description: Direkte Wege zur Kontaktaufnahme, dazu Ansprechpartnerin, Veranstalter und Presse.
 * Block Types: core/post-content
 * Post Types: page
 * Inserter: yes
 *
 * Diese Datei wird von tools/make-patterns.php erzeugt.
 * Quelle: inhalte/06-kontakt.html
 *
 * @package Lindenzauber
 */

?>
<!-- wp:group {"align":"full","className":"is-style-lz-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lz-band"><!-- wp:paragraph {"align":"center","className":"is-style-lz-lead"} -->
<p class="has-text-align-center is-style-lz-lead">Sie haben eine Frage zum Fest, zur Anfahrt oder zur Barrierefreiheit? Melden Sie sich gern – wir freuen uns über jede Nachricht.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Am schnellsten geht es per E-Mail oder WhatsApp. Wir antworten in der Regel innerhalb weniger Tage.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"var:preset|spacing|30"} -->
<div style="height:var(--wp--preset--spacing--30)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="mailto:info@lindenzauber.de">E-Mail schreiben</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="tel:+491737699963">Anrufen oder WhatsApp</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"is-style-lz-panel","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lz-panel"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"className":"is-style-lz-karte"} -->
<div class="wp-block-column is-style-lz-karte"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ansprechpartnerin</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"gross"} -->
<p class="has-gross-font-size">Brigitta Wortmann</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Konzeption und Organisation des Lindenzaubers<br>Eschenhausen 3, 27211 Bassum</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-lz-karte"} -->
<div class="wp-block-column is-style-lz-karte"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">E-Mail</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"gross"} -->
<p class="has-gross-font-size"><a href="mailto:info@lindenzauber.de">info@lindenzauber.de</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Für alle Fragen rund um das Fest.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-lz-karte"} -->
<div class="wp-block-column is-style-lz-karte"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Telefon und WhatsApp</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"gross"} -->
<p class="has-gross-font-size"><a href="tel:+491737699963">0173 769 99 63</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Auch als WhatsApp-Nachricht erreichbar.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"is-style-lz-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lz-band"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Veranstalter</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Mütter-Kinder-Zentrum Bassum e. V.<br>Mittelstraße 2, 27211 Bassum<br>Telefon: <a href="tel:+4942414842">04241 4842</a><br><a href="https://www.muekize-bassum.de/" rel="noopener">muekize-bassum.de</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Presse und Aushang</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Plakat und Pressetext stellen wir gern zur Verfügung – in Druckqualität und als Datei zum Weitergeben. Eine kurze Nachricht genügt.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
