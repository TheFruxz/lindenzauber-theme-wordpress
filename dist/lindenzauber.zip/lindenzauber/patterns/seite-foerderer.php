<?php
/**
 * Title: Seite: Förderer
 * Slug: lindenzauber/seite-foerderer
 * Categories: lindenzauber
 * Description: Vier große Förderer-Kacheln, die komplett anklickbar sind.
 * Block Types: core/post-content
 * Post Types: page
 * Inserter: yes
 *
 * Diese Datei wird von tools/make-patterns.php erzeugt.
 * Quelle: inhalte/05-foerderer.html
 *
 * @package Lindenzauber
 */

?>
<!-- wp:group {"align":"full","className":"is-style-lz-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lz-band"><!-- wp:paragraph {"align":"center","className":"is-style-lz-lead"} -->
<p class="has-text-align-center is-style-lz-lead">Der Lindenzauber wird möglich durch die Unterstützung engagierter Partner, die Kultur, Gemeinschaft und lebendiges Erzählen fördern.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Weil alle vier gemeinsam tragen, was hier entsteht, ist der Eintritt an beiden Tagen frei. Unser herzlicher Dank gilt:</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"is-style-lz-panel","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lz-panel"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"className":"is-style-lz-foerderer"} -->
<div class="wp-block-column is-style-lz-foerderer"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://lindenzauber.de/wp-content/uploads/2026/08/Avacon-1024x640.png" alt="Logo von Avacon"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><a href="https://www.avacon.de/de.html" rel="noopener">Avacon</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-lz-foerderer"} -->
<div class="wp-block-column is-style-lz-foerderer"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://lindenzauber.de/wp-content/uploads/2026/08/Bassum-1024x640.png" alt="Logo der Stadt Bassum"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><a href="https://www.bassum.de/" rel="noopener">Stadt Bassum</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"className":"is-style-lz-foerderer"} -->
<div class="wp-block-column is-style-lz-foerderer"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://lindenzauber.de/wp-content/uploads/2026/08/Weser-Hunte1-1024x640.png" alt="Logo des Landschaftsverbands Weser-Hunte e. V."/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><a href="https://www.weser-hunte.de/" rel="noopener">Landschaftsverband Weser-Hunte e. V.</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-lz-foerderer"} -->
<div class="wp-block-column is-style-lz-foerderer"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://lindenzauber.de/wp-content/uploads/2026/08/Volksbank-1024x640.png" alt="Logo der Volksbank Bassum-Syke"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><a href="https://www.volksbank-niedersachsen-mitte.de/startseite.html" rel="noopener">Volksbank Bassum-Syke</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"is-style-lz-band","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lz-band"><!-- wp:paragraph {"align":"center","className":"is-style-lz-hinweis"} -->
<p class="has-text-align-center is-style-lz-hinweis">Danke, dass Sie das Erzählen möglich machen</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Ein besonderer Dank gilt außerdem dem Kindergarten KinderReich, der dem Lindenzauber an beiden Tagen sein Haus öffnet.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
